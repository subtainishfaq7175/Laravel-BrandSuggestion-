$(function(){
  $.okvideo({
      source: '158075143',
      volume: 0,
	controls: false,
	captions: false,
	autoplay: true,
	disablekeyControl: true
  });
});

