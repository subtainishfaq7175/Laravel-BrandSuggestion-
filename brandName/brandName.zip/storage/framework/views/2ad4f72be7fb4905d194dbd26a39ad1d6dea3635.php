<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"> <center> <h2>New Request Details </h2></center> </div>

                <div class="panel-body">
                    <table class="table">
                        <tr><th>Title</th>
                            <th>Description</th>  </tr>


                            <tr> <td>Requset title</td> <td><?php echo e($request->title); ?> </td> </tr>
                            <tr> <td>Request description</td> <td><?php echo e($request->description); ?> </td> </tr>
                            <tr> <td>Request remark</td> <td><?php echo e($request->remarks); ?> </td> </tr>


                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php echo $__env->make('commun.buyerHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>