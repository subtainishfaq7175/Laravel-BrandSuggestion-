<?php echo $__env->make('commun.buyerHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Rating on response</div>

                <div class="panel-body">
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success"> <?php echo e(Session::get('message')); ?> </div>
                    <?php endif; ?>
                    <table class="table">
                        <tr> <th>Suggesst Doamin</th> <th></th> </tr>
                        <?php $__currentLoopData = $respondedProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr><td>Domain Name</td> <td><?php echo e($product->name); ?></td>  </tr>
                                    <tr><td>Domain Heading</td> <td><?php echo e($product->heading); ?></td>  </tr>
                                    <tr><td>Domain sub Heading</td> <td><?php echo e($product->subheading); ?></td>  </tr>
                                    <tr><td>Domain Description</td> <td><?php echo e($product->description); ?></td>  </tr>
                                    <tr><td>Domain Price</td> <td><?php echo e($product->price); ?> $</td>  </tr>
                                    <tr><td>Ratting to this response</td> <td><form action="<?php echo e(route('doRating')); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <select name="rate">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                </select>
                                                <input type="submit" value="Submit">
                                            </form></td>  </tr>

                                    <tr><td></td> <td><a class="btn-success" href="<?php echo e(route('payments')); ?>">Purchase</a></td></tr>
                                <tr style="background-color: #00BCD4"><td></td> <td></td>  </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>

                    
                </div>

            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('commun.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>