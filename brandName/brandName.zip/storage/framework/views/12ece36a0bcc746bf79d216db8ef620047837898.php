<?php echo $__env->make('commun.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success"> <?php echo e(Session::get('message')); ?> </div>
            <?php endif; ?>

            <div class="panel panel-default">
                <div class="panel-heading"> <center> <h2>Respond to request </h2></center> </div>

                <div class="panel-body">
                    <table class="table">
                        <th>Selection</th>
                        <th>Action</th>
                        <?php echo Form::open(array('route'=>'respond')); ?>

                        <tr><td>Select domian to respond
                                <select class="selectpicker" name="selectpicker">
                                    <option></option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <input type="hidden" name="id" value="<?php echo e($id); ?>">
                            <td><?php echo Form::button('Submit',['type'=>'submit', 'class'=>'btn btn-primary']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php echo $__env->make('commun.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>