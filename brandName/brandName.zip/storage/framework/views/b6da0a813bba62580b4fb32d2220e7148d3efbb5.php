<?php echo $__env->make('commun.sallerHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="panel panel-default">
                                <div class="panel-heading"> <center> <h2>New Requests </h2></center> </div>

                                <div class="panel-body">
                                        <?php $__currentLoopData = $newRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <table class="table">
                                                <tr><th>Title</th>
                                                    <th>Description</th>  </tr>
                                                <tr> <td>Requset title</td> <td><?php echo e($item->title); ?> </td> </tr>
                                                <tr> <td>Request description</td> <td><?php echo e($item->description); ?> </td> </tr>
                                                <tr> <td>Request remark</td> <td><?php echo e($item->remarks); ?> </td> </tr>
                                                <tr> <td>Add by user </td> <td><?php echo e($item->userid); ?> </td> </tr>
                                                <tr> <td></td> <td><?php echo e(link_to_route('doResponse','Respose',[$item->id], ['class'=>'btn btn-info pull-right'])); ?> </td> </tr>

                                            </table>
                                            <p style="border-bottom: 3px solid; "></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <div class="panel-heading"> <center> <h2>Respond Requests </h2></center> </div>

                                <div class="panel-body">
                                    <?php $__currentLoopData = $responedRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <table class="table">
                                            <tr><th>Title</th>
                                                <th>Description</th>  </tr>
                                            <tr> <td>Requset title</td> <td><?php echo e($item->title); ?> </td> </tr>
                                            <tr> <td>Request description</td> <td><?php echo e($item->description); ?> </td> </tr>
                                            <tr> <td>Request remark</td> <td><?php echo e($item->remarks); ?> </td> </tr>
                                            <tr> <td>Add by user </td> <td><?php echo e($item->userid); ?> </td> </tr>
                                            <tr> <td></td> <td><?php echo e(link_to_route('Response','Show Respose',[$item->id], ['class'=>'btn btn-info pull-right'])); ?> </td> </tr>

                                        </table>
                                        <p style="border-bottom: 3px solid; "></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>

<?php echo $__env->make('commun.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>