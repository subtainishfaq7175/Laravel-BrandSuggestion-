<?php echo $__env->make('commun.sallerHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Create New Domain</div>

                <div class="panel-body">
                    <?php echo Form::open(array('route'=>'products.store')); ?>

                    <div class="form-group">
                        <?php echo Form::label('title','Name'); ?>

                        <?php echo Form::text('name',null , ['class'=>'form-control','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('body','Heading'); ?>

                        <?php echo Form::text('heading',null , ['class'=>'form-control' ,'required' ]); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('deadline','Sub heading'); ?>

                        <?php echo Form::text('subheading',null , ['class'=>'form-control' ,'required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('riminder','Category'); ?>

                        <?php echo Form::text('category',null , ['class'=>'form-control' ,'required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('r_mesg','Price'); ?>

                        <?php echo Form::number('price',null , ['class'=>'form-control','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('status','Domain name'); ?>

                        <?php echo Form::text('domain_name',null , ['class'=>'form-control','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('status','Description'); ?>

                        <?php echo Form::text('description',null , ['class'=>'form-control','required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('status','Rating'); ?>

                        <?php echo Form::text('rating',null , ['class'=>'form-control','required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('status','Unit Time'); ?>

                        <?php echo Form::text('unitTime',null , ['class'=>'form-control','required']); ?>

                    </div>
                    <div class="form-group">

                        <?php echo Form::button('Create',['type'=>'submit', 'class'=>'btn btn-primary']); ?>

                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>
    </div>
</div>

<?php echo $__env->make('commun.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>