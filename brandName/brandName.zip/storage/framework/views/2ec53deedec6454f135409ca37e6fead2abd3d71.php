<?php echo $__env->make('commun.buyerHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success"> <?php echo e(Session::get('message')); ?> </div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">Products</div>

                <div class="panel-body">
                    <table class="table">
                        <tr>
                            <th>Request ID</th>
                            <th>Title</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>  <?php echo e($request->id); ?> </td>
                                <td>  <?php echo e(link_to_route('request.show',$request->title,[$request->id])); ?> </td>
                                <td>
                                    <?php echo Form::open(array('route'=>['request.destroy',$request->id], 'method'=>'DELETE')); ?>

                                    <?php echo e(link_to_route('request.edit','Edit',[$request->id], ['class'=>'btn btn-primary'])); ?>


                                    |
                                    <?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?> |
                                    <?php echo e(link_to_route('showResponse','Show response',[$request->id], ['class'=>'btn btn-primary'])); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>
            </div>
            <?php echo e(link_to_route('request.create','Add new request',null, ['class'=>'btn btn-success'])); ?>


        </div>
    </div>
</div>

<?php echo $__env->make('commun.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>