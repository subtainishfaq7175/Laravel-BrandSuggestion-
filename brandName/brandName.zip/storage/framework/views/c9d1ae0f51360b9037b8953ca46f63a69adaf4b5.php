<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Add new domain request</div>

                <div class="panel-body">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo e(implode('', $errors->all() )); ?>

                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php echo Form::open(array('route'=>'adDomainRequest')); ?>

                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title',null , ['class'=>'form-control','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('body','Description'); ?>

                        <?php echo Form::textarea('description',null , ['class'=>'form-control' ,'required' ]); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('body','File'); ?>

                        <?php echo Form::file('file',null , ['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('deadline','Remarks'); ?>

                        <?php echo Form::text('remarks',null , ['class'=>'form-control' ,'required']); ?>

                    </div>
                    <?php echo Form::button('Create',['type'=>'submit', 'class'=>'btn btn-primary']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>
    </div>
</div>
<?php echo $__env->make('commun.buyerHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>