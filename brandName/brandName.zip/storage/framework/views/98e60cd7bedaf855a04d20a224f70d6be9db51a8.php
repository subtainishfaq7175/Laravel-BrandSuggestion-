<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"> <center> <h2>Product Details </h2></center> </div>

                <div class="panel-body">
                    <table class="table">
                        <tr> <td>Product Name</td> <td><?php echo e($product->name); ?> </td> </tr>
                        <tr> <td>Product heading</td> <td><?php echo e($product->heading); ?> </td> </tr>
                        <tr> <td>Product sub heading</td> <td><?php echo e($product->subheading); ?> </td> </tr>
                        <tr> <td>Product category</td> <td><?php echo e($product->category); ?> </td> </tr>
                        <tr> <td>Product price</td> <td><?php echo e($product->price); ?> </td> </tr>
                        <tr> <td>Domian name</td> <td><?php echo e($product->domain_name); ?> </td> </tr>
                        <tr> <td>Product Description</td> <td><?php echo e($product->description); ?> </td> </tr>
                        <tr> <td>Product rating</td> <td><?php echo e($product->rating); ?> </td> </tr>
                        <tr> <td>Product unit time</td> <td><?php echo e($product->unitTime); ?> </td> </tr>
                        <tr> <td>Product created at</td> <td><?php echo e($product->created_at); ?> </td> </tr>
                        <tr> <td>Product updated at</td> <td><?php echo e($product->updated_at); ?> </td> </tr>
                    </table>
                    <td> <button class="btn-black btn-primary pull-right" > <?php echo e(link_to_route('products.index','Home')); ?> </button> </td>

                </div>
            </div>

        </div>
    </div>
</div>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>