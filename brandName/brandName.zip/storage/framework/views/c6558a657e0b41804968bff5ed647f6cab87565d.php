<body id="page-top">

<div class="body">
	<!-- HEADER -->
<?php echo $__env->make('commun.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- INTRO -->
	<div class="intro intro-style1">
		<div class="overlay"></div>
		<div class="container">
			<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<ul>
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo e(implode('', $errors->all() )); ?>

					</ul>
				</div>
			<?php endif; ?>
				<?php if(session('err')): ?>
					<div class="alert alert-danger">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <?php echo e(session('err')); ?>

					</div>
				<?php endif; ?>

				<?php if(session('message')): ?>

					<div class="alert alert-success" id="success-alert">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <?php echo e(session('message')); ?>

					</div>
				<?php endif; ?>
			<div class="row center-content">
				<div class="col-md-6 col-sm-8 col-sm-offset-2">
					<h2>What is NAMESQUAD?</h2>
					<p>Get your name in just 4 steps</p>
					<?php if(Auth::check() ): ?>
						<?php if(Auth::user()->accout == 2): ?>
							<?php echo e(link_to_route('request.create','Add new request',null, ['class'=>'btn btn-success btn-large'])); ?>

						<?php endif; ?>
					<?php endif; ?>

					<?php if(Auth::check() ): ?>
						<?php if(Auth::user()->accout == 1): ?>
							<?php echo e(link_to_route('products.create','Add new request',null, ['class'=>'btn btn-success btn-large'])); ?>

						<?php endif; ?>
					<?php endif; ?>
					<a href="#" disabled class="btn btn-default btn-border btn-lg">Take Tour</a>
				</div>
				<div class="col-md-5 col-md-push-1">
					<img src="<?php echo e(url('assets/images/1.png')); ?>" class="img-responsive" alt="Item pic may be.."/>
				</div>
			</div>
		</div>
	</div>



	<?php echo $__env->make('commun.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layout.user-login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layout.user-signup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layout.forget-password', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layout.logout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</div>





<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>